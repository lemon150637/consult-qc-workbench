"""Publish only generated annotation HTML, using the installed Popo uploader."""
import json
from pathlib import Path
import re
import subprocess
import sys
import threading
import uuid
import urllib.request

ROOT=Path(__file__).resolve().parent
PROJECT=ROOT
SKILL=ROOT/'vendor/popo'
JOBS={}
LOCK=threading.RLock()
PUBLISH_LOCK=threading.Lock()

def validate(headers,rows,title,visibility,confirmed):
    if visibility not in ('internal','private'):raise ValueError('请选择公开或不公开')
    if visibility=='internal' and confirmed is not True:raise ValueError('请确认当前健康对话可公开给所有已登录泡泡用户')
    if not isinstance(title,str) or not title.strip() or len(title)>100:raise ValueError('作品名称需为 1–100 个字符')
    if not isinstance(headers,list) or not all(isinstance(h,str) for h in headers) or len(headers)!=len(set(headers)):raise ValueError('表头不合法')
    if not isinstance(rows,list) or not 1<=len(rows)<=500 or not all(isinstance(r,dict) for r in rows):raise ValueError('需 1–500 条结果')
    if not all(k in headers for k in ('判断','问题类型','问题定位')):raise ValueError('缺少质检结果字段')
    content=json.dumps(rows,ensure_ascii=False)
    if re.search(r'\bsk-[A-Za-z0-9_-]{20,}',content):raise ValueError('内容中检测到疑似模型密钥，请移除后再发布')

def status(jid):
    with LOCK:
        if jid not in JOBS:raise ValueError('发布任务不存在')
        return dict(JOBS[jid])

def start(html,title,visibility):
    jid=uuid.uuid4().hex
    slug='consult-qc-'+jid[:14]
    directory=PROJECT/'outputs'/'published-annotations'/jid
    directory.mkdir(parents=True)
    (directory/'index.html').write_text(html,encoding='utf-8')
    with LOCK:JOBS[jid]={'id':jid,'state':'publishing','title':title,'slug':slug,'visibility':visibility}
    threading.Thread(target=worker,args=(jid,directory,title,slug,visibility),daemon=True).start()
    return status(jid)

def worker(jid,directory,title,slug,visibility):
    try:
        with PUBLISH_LOCK:
            script=SKILL/'scripts/upload.py'
            if not script.exists():raise ValueError('本机未安装泡泡发布技能')
            # macOS system curl uses the system trust store. Keep certificate
            # verification enabled; Python's bundled CA store lacks the issuer here.
            check=subprocess.run(['/usr/bin/curl','--fail','--silent','--show-error','--connect-timeout','10','--max-time','25',
                'https://api.popo.baidu-int.com/works/slug-availability?slug='+slug],
                text=True,capture_output=True,timeout=30)
            if check.returncode:
                if check.returncode==60:raise ValueError('链接检查失败：系统无法验证泡泡站点证书，请检查公司网络证书配置；尚未上传内容')
                if check.returncode in (5,6):raise ValueError('链接检查失败：无法解析泡泡地址，请连接公司网络；尚未上传内容')
                if check.returncode in (7,28):raise ValueError('链接检查失败：无法连接泡泡或连接超时；尚未上传内容')
                raise ValueError('链接检查失败（系统网络工具返回 '+str(check.returncode)+'）；尚未上传内容')
            try:availability=json.loads(check.stdout)
            except ValueError:raise ValueError('链接检查返回内容不是预期格式；尚未上传内容') from None
            if availability.get('data',{}).get('available') is not True:raise ValueError('专属链接不可用，请重新创建发布任务')
            # All arguments are structured; no shell or arbitrary files can be selected.
            account_args=[]
            account_file=ROOT/'.runtime/popo-account.json'
            if account_file.exists():
                account=json.loads(account_file.read_text()).get('username','')
                if re.fullmatch(r'[A-Za-z0-9._-]+',account):account_args=['--username',account]
            result=subprocess.run([sys.executable,str(script),'--source','codex','--title',title,'--slug',slug,'--visibility',visibility,'--base',str(directory),'--entry','index.html']+account_args,cwd=PROJECT,text=True,capture_output=True,timeout=180)
            if result.returncode:
                text=result.stderr
                if 'NEED_LOGIN:MISSING' in text:raise ValueError('发布前需要登录公司账号，请联系工作台维护者配置泡泡登录')
                if 'NEED_LOGIN:AMBIGUOUS' in text:raise ValueError('检测到多个公司账号，需要选择发布账号')
                if 'NO_PERMISSION' in text:raise ValueError('当前账号没有发布权限')
                if 'VISIBILITY_CONFIRM_REQUIRED' in text:raise ValueError('泡泡要求确认可见性变更；本次未发布')
                raise ValueError('泡泡未确认发布成功，请检查公司网络或登录状态后查看泡泡作品列表')
            payload=None
            for line in result.stdout.splitlines():
                try:value=json.loads(line)
                except ValueError:continue
                if isinstance(value,dict) and value.get('success'):payload=value
            if not payload:raise ValueError('发布响应未确认成功，请先查看泡泡作品列表，避免重复发布')
            url='https://'+slug+'.popo.baidu-int.com'
            with LOCK:JOBS[jid].update(state='published',url=url,workId=payload.get('data',{}).get('workId'))
            (directory/'publish-record.json').write_text(json.dumps(status(jid),ensure_ascii=False,indent=2))
    except Exception as exc:
        message=str(exc) if isinstance(exc,ValueError) else '发布未完成，请检查网络或公司登录状态；请先查看泡泡作品列表再重试'
        with LOCK:JOBS[jid].update(state='failed',error=message)
        try:(directory/'publish-record.json').write_text(json.dumps(status(jid),ensure_ascii=False,indent=2))
        except OSError:pass
