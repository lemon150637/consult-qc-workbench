"""Store the recipient's own Popo login without showing it in process arguments."""
import getpass,json,re,os
from pathlib import Path

def main():
    print('泡泡发布需要公司账号。请先在浏览器打开 https://uuap.baidu.com/agent/token 获取你自己的登录信息。')
    username=input('公司账号邮箱前缀：').strip()
    if not re.fullmatch(r'[A-Za-z0-9._-]+',username):raise ValueError('账号前缀格式不正确')
    token=getpass.getpass('粘贴登录信息（输入不回显），然后按回车：').strip()
    if token.startswith('{'):
        token=json.loads(token).get('token','')
    else:
        match=re.search(r'ugate\s+token\s*[:：]\s*(\S.+)',token,re.I)
        if match:token=match.group(1).strip()
    if not isinstance(token,str) or not token or '\n' in token or '\r' in token:raise ValueError('登录信息为空或格式不正确')
    folder=Path.home()/'.config/uuap';folder.mkdir(parents=True,exist_ok=True)
    file=folder/('.eac_ugate_token_'+username)
    if file.exists() and input('已存在此账号登录信息，更新？输入 yes：').strip()!='yes':return
    fd=os.open(file,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
    with os.fdopen(fd,'w') as f:json.dump({'token':token,'permanent':True},f)
    os.chmod(file,0o600)
    config=Path(__file__).resolve().parent/'.runtime';config.mkdir(exist_ok=True)
    (config/'popo-account.json').write_text(json.dumps({'username':username}))
    print('登录配置已保存到本机。请只在公司网络环境使用泡泡发布。')

if __name__=='__main__':
    try:main()
    except Exception as e:print('未完成：'+type(e).__name__+'，请核对账号及登录信息。')
