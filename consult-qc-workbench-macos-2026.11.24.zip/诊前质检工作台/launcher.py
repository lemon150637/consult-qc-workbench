#!/usr/bin/env python3
"""Portable macOS launcher. No administrator access or Codex installation needed."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import socket
import subprocess
import sys
import time
import urllib.request
import venv
import webbrowser

ROOT=Path(__file__).resolve().parent
BUILD='portable-20261124'
PORT=8767
URL=f'http://127.0.0.1:{PORT}'

def health():
    try:
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(URL+'/api/health',timeout=2) as r:return json.load(r)
    except (OSError,ValueError):return None

def ensure_environment():
    python=ROOT/'.venv/bin/python3'
    if not python.exists():
        print('正在创建独立 Python 环境…',flush=True)
        venv.EnvBuilder(with_pip=True).create(ROOT/'.venv')
    result=subprocess.run([str(python),'-c','import requests'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    if result.returncode:
        print('首次使用：安装模型调用依赖 requests，需要联网…',flush=True)
        subprocess.run([str(python),'-m','pip','install','-r',str(ROOT/'requirements.txt')],check=True)
    return python

def prepare_folder():
    folder=Path.home()/'Desktop'/'诊前checklist';folder.mkdir(parents=True,exist_ok=True)
    runner=folder/'openai-request.py';source=ROOT/'openai-request-safe.py'
    if not runner.exists():
        with runner.open('xb') as f:f.write(source.read_bytes())
        print('评测脚本已安装：'+str(runner),flush=True)
    elif runner.read_bytes()!=source.read_bytes():
        alternative=folder/'openai-request-workbench.py'
        if not alternative.exists():
            with alternative.open('xb') as f:f.write(source.read_bytes())
        print('发现你已有的 openai-request.py，已保留。工作台脚本：'+str(alternative),flush=True)
    print('输入 TXT 和评测结果目录：'+str(folder),flush=True)
    return folder

def listener_ids():
    r=subprocess.run(['/usr/sbin/lsof','-nP','-t',f'-iTCP:{PORT}','-sTCP:LISTEN'],capture_output=True,text=True)
    if r.returncode not in (0,1):raise RuntimeError('无法查询服务进程')
    return {int(x) for x in r.stdout.split()}

def stop_owned_service():
    current=health()
    if not current:return
    if current.get('installation')!=str(ROOT):raise RuntimeError('8767 正在被另一份工作台使用，未停止或覆盖它。请先关闭那份工作台。')
    pids=listener_ids()
    for pid in pids:
        r=subprocess.run(['/usr/sbin/lsof','-a','-p',str(pid),'-d','cwd','-Fn'],capture_output=True,text=True,check=True)
        if 'n'+str(ROOT) not in r.stdout.splitlines():raise RuntimeError('进程目录不匹配，未停止其他应用')
    for pid in pids:os.kill(pid,signal.SIGTERM)
    deadline=time.monotonic()+10
    while listener_ids() and time.monotonic()<deadline:time.sleep(.2)
    if listener_ids():raise RuntimeError('旧服务尚未退出')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--restart',action='store_true');parser.add_argument('--stop',action='store_true');parser.add_argument('--no-open',action='store_true');args=parser.parse_args()
    if sys.platform!='darwin':raise RuntimeError('此双击安装包面向 macOS。Windows 不支持本版网页终端。')
    if sys.version_info<(3,10):raise RuntimeError('需要 Python 3.10 或更新版本，请从 python.org 安装。')
    if args.stop:
        stop_owned_service();print('本份工作台服务已停止。');return
    if args.restart:stop_owned_service()
    current=health()
    if current:
        if current.get('installation')!=str(ROOT):raise RuntimeError('8767 被另一份工作台占用，请先停止该工作台。')
        if current.get('build')!=BUILD:raise RuntimeError('服务版本不同，请使用“重启工作台.command”。')
    else:
        with socket.socket() as sock:
            sock.settimeout(1)
            if sock.connect_ex(('127.0.0.1',PORT))==0:raise RuntimeError('8767 已被其他程序占用，未关闭该程序。')
        python=ensure_environment();prepare_folder()
        runtime=ROOT/'.runtime';runtime.mkdir(exist_ok=True)
        with (runtime/'local-server.log').open('ab') as log:
            child=subprocess.Popen([str(python),'-u',str(ROOT/'server.py'),'--port',str(PORT),'--data-dir',str(runtime)],cwd=ROOT,stdin=subprocess.DEVNULL,stdout=log,stderr=log,start_new_session=True,close_fds=True)
        deadline=time.monotonic()+15
        while time.monotonic()<deadline:
            current=health()
            if current and current.get('build')==BUILD and current.get('installation')==str(ROOT):break
            if child.poll() is not None:raise RuntimeError('服务退出，请检查 .runtime/local-server.log')
            time.sleep(.2)
        else:raise RuntimeError('服务未在预期时间就绪，请检查日志')
    print('已验证版本：'+BUILD,flush=True);print('工作台地址：'+URL,flush=True)
    print('后台服务已运行；电脑重启后再双击“启动工作台.command”。',flush=True)
    if not args.no_open:webbrowser.open(URL)

if __name__=='__main__':
    try:main()
    except Exception as e:
        print('启动未完成：'+str(e),file=sys.stderr,flush=True);sys.exit(1)
