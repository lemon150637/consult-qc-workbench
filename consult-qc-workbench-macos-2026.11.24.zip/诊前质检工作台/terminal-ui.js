/* xterm.js frontend; a live PTY, not a simulated command transcript. */
window.EmbeddedTerminal = (() => {
  let panel, terminal, fit, sid=null, token=null, cursor=0, generation=0;
  let connecting=false, stopped=true, writes=Promise.resolve(), lastSize='';
  const el=id=>panel.querySelector('#'+id);
  function state(text,kind=''){el('terminal-state').textContent=text;el('terminal-state').dataset.state=kind;}
  async function call(action,data={}){
    const response=await fetch('/api/terminal/'+action,{method:'POST',headers:{'Content-Type':'application/json','X-Terminal-Token':token},body:JSON.stringify({id:sid,...data})});
    const result=await response.json();
    if(!response.ok)throw Error(result.error||'终端连接失败');
    return result;
  }
  function init(){
    if(panel)return;
    try{sid=sessionStorage.getItem('preconsult-terminal-id')||null}catch{}
    panel=document.createElement('section');panel.className='embedded-terminal';
    panel.innerHTML=`<div class="terminal-toolbar"><strong>本机终端</strong><span id="terminal-state" role="status">尚未连接</span><div class="actions"><button id="terminal-connect" type="button">连接终端</button><button id="terminal-interrupt" type="button" disabled>中断 Ctrl+C</button><button id="terminal-clear" type="button">清屏</button><button id="terminal-close" type="button" disabled>结束会话</button></div></div><div class="terminal-directory" id="terminal-directory">工作目录：~/Desktop/诊前checklist</div><div id="terminal-screen" aria-label="网页内本机终端"></div><div class="terminal-foot">点击黑色区域输入命令，按 Enter 执行。切换页面不会停止运行；“结束会话”会关闭当前 Shell。输入与输出仅保留在会话内存中。</div>`;
    terminal=new Terminal({cursorBlink:true,convertEol:false,scrollback:3000,screenReaderMode:true,
      fontFamily:'Menlo, Monaco, "PingFang SC", monospace',fontSize:13,
      theme:{background:'#101c18',foreground:'#dfebe4',cursor:'#b1e5c0',selectionBackground:'#3f6555',black:'#182b23',green:'#98dcb0',brightGreen:'#b7e6c2'}});
    fit=new FitAddon.FitAddon();terminal.loadAddon(fit);
    el('terminal-connect').onclick=()=>open();
    el('terminal-interrupt').onclick=()=>{enqueue('\x03');terminal.focus()};
    el('terminal-clear').onclick=()=>{terminal.clear();terminal.focus()};
    el('terminal-close').onclick=()=>close();
    terminal.onData(text=>enqueue(text));
    terminal.attachCustomKeyEventHandler(e=>{
      // Preserve browser copy/paste shortcuts; xterm handles clipboard paste itself.
      if((e.metaKey||e.ctrlKey)&&e.shiftKey&&e.key.toLowerCase()==='c')return false;
      return true;
    });
    new ResizeObserver(()=>size()).observe(panel);
  }
  let opened=false;
  function mount(){
    const host=document.querySelector('#terminal-host');
    if(!host)return;
    init();host.appendChild(panel);
    if(!opened){terminal.open(el('terminal-screen'));opened=true;}
    requestAnimationFrame(size);
  }
  function size(){
    if(!opened||!panel.isConnected||panel.getBoundingClientRect().width<100)return;
    fit.fit();const next=terminal.cols+':'+terminal.rows;
    if(sid&&!stopped&&next!==lastSize){lastSize=next;call('resize',{cols:terminal.cols,rows:terminal.rows}).catch(e=>state(e.message,'error'));}
  }
  function enqueue(text){
    if(!sid||stopped)return;
    const id=sid,epoch=generation;
    writes=writes.then(async()=>{
      if(epoch!==generation||id!==sid)return;
      // Paste chunks remain ordered even during a long paste or rapid keystrokes.
      for(let i=0;i<text.length;i+=4096)await call('input',{id,text:text.slice(i,i+4096)});
    }).catch(e=>{state(e.message,'error')});
  }
  async function pump(epoch){
    while(epoch===generation&&!stopped){
      try{
        const result=await call('read',{cursor});
        if(epoch!==generation)return;
        if(result.gap)terminal.writeln('\r\n[输出缓存已更新，部分早期内容未保留]\r\n');
        const bytes=Uint8Array.from(atob(result.data),c=>c.charCodeAt(0));
        if(bytes.length)await new Promise(resolve=>terminal.write(bytes,resolve));
        cursor=result.cursor;
        if(result.exited&&bytes.length===0){stopped=true;state('Shell 已退出（'+result.exit_code+'）','closed');buttons();break;}
      }catch(e){
        if(epoch!==generation)return;
        // Retain the session identity so reconnect attaches, never duplicates a running command.
        stopped=true;state(e.message+'；可点击重新连接','error');buttons();break;
      }
    }
  }
  function buttons(){el('terminal-connect').disabled=connecting||(!stopped&&!!sid);el('terminal-connect').textContent=sid?'重新连接':'连接终端';el('terminal-interrupt').disabled=stopped;el('terminal-close').disabled=!sid;}
  async function open(){
    mount();if(!panel||connecting)return;
    if(sid&&!stopped){terminal.focus();return;}
    connecting=true;buttons();state('正在连接本机 Shell…');
    try{
      if(location.protocol==='file:')throw Error('请从 http://127.0.0.1:8766 打开工作台');
      if(!token){const r=await fetch('/api/terminal-auth');if(!r.ok)throw Error('本地服务尚未更新，请重启服务');token=(await r.json()).token;}
      if(sid){
        try{const r=await call('read',{cursor});if(r.exited)throw Error('exited');}
        catch(e){if(!/不存在|失效|exited/.test(e.message))throw e;sid=null;token=(await (await fetch('/api/terminal-auth')).json()).token;}
      }
      if(!sid){
        const result=await call('create',{cols:terminal.cols,rows:terminal.rows});
        sid=result.id;cursor=0;terminal.reset();el('terminal-directory').textContent='启动目录：'+result.cwd;
      }
      try{sessionStorage.setItem('preconsult-terminal-id',sid)}catch{}
      stopped=false;state('已连接 · 可直接输入命令','connected');
      generation++;size();pump(generation);terminal.focus();
    }catch(e){stopped=true;state(e.message,'error');}
    finally{connecting=false;buttons();}
  }
  async function close(){
    if(!sid)return;
    try{await call('close');stopped=true;generation++;sid=null;try{sessionStorage.removeItem('preconsult-terminal-id')}catch{}state('会话已关闭','closed');terminal.writeln('\r\n[会话已关闭]\r\n');buttons();}
    catch(e){state(e.message,'error');}
  }
  return {mount,open};
})();
