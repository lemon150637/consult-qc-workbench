#!/bin/zsh
cd -- "${0:A:h}" || exit 1
if ! command -v python3 >/dev/null 2>&1; then
  print '需要 Python 3.10 或更新版本，请从 https://www.python.org/downloads/macos/ 安装。'
  read -r '?按回车关闭…'
  exit 1
fi
python3 configure_popo.py 
status_code=$?
print ''
read -r '?按回车关闭窗口（已启动的后台网站会继续运行）…'
exit $status_code
