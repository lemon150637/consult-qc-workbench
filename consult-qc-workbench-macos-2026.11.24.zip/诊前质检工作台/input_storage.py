"""Save reviewed TXT to the user's evaluation folder, using the requested filename and atomic replacement."""
import json
import os
from pathlib import Path
import re
import tempfile
from datetime import datetime

FOLDER=Path.home()/'Desktop'/'诊前checklist'

def save_txt(name,text):
    if not isinstance(name,str) or not name.strip() or len(name)>160 or any(c in name for c in '/\\\x00\r\n') or name in ('.','..'):
        raise ValueError('请输入文件名，不要包含路径')
    name=name.strip()
    if not name.lower().endswith('.txt'):name+='.txt'
    if not isinstance(text,str) or not text.strip():raise ValueError('TXT 内容为空')
    lines=text.splitlines();seen=set();count=0;prompts=set()
    for no,line in enumerate(lines,1):
        if not line.strip():raise ValueError(f'第 {no} 行为空')
        try:r=json.loads(line)
        except ValueError:raise ValueError(f'第 {no} 行不是有效 JSON') from None
        if not isinstance(r,dict) or not isinstance(r.get('checklist'),str) or not r['checklist'].strip():raise ValueError(f'第 {no} 行缺少 checklist')
        d=r.get('input_data')
        if not isinstance(d,dict) or any(not isinstance(d.get(k),str) or not d[k].strip() for k in ('批次id','内容id','标注case')):raise ValueError(f'第 {no} 行缺少 ID 或对话')
        key=(d['批次id'],d['内容id'])
        if key in seen:raise ValueError(f'第 {no} 行 ID 重复')
        seen.add(key);prompts.add(r['checklist']);count+=1
    if len(prompts)!=1:raise ValueError('TXT 含多个 checklist 版本')
    if not FOLDER.is_dir():raise ValueError('诊前checklist 文件夹不存在')
    target=FOLDER/name
    if target.is_symlink():raise ValueError('目标不能是符号链接')
    existed=target.exists()
    temp=None
    try:
        with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',newline='',dir=FOLDER,prefix='.txt-save-',delete=False) as f:
            temp=Path(f.name)
            f.write(text);f.flush();os.fsync(f.fileno())
        os.replace(temp,target)
        temp=None
        return {'path':str(target),'name':name,'rows':count,'overwritten':existed}
    finally:
        if temp is not None:temp.unlink(missing_ok=True)
