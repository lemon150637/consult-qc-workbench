"""PTY child bootstrap; no HTTP or user commands are evaluated here."""
import fcntl
import os
import sys
import termios

slave = int(sys.argv[1])
os.setsid()
fcntl.ioctl(slave, termios.TIOCSCTTY, 0)
for fd in (0, 1, 2):
    os.dup2(slave, fd)
if slave > 2:
    os.close(slave)
shell = '/bin/zsh' if os.path.isfile('/bin/zsh') else '/bin/bash'
# A separate interactive shell, with no user rc or shell-history writes.
args = [shell, '-d', '-f', '-i'] if shell.endswith('zsh') else [shell, '--noprofile', '--norc', '-i']
os.execve(shell, args, os.environ)
