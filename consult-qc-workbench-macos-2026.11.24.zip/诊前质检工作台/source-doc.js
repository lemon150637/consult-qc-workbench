window.SOURCE_DOCUMENT="来源文档待导入\n\n请在 Checklist / Prompt 页面上传本团队的 TXT 或 Markdown 来源文档。当前 Prompt 为本工具预置的诊前质检规则，来源关联请由使用者核对。";
window.SOURCE_DOCUMENT_NAME="待导入的团队来源文档.txt";
