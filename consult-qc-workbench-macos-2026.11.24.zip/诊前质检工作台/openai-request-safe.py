#!/usr/bin/env python3
"""Compatible batch runner: validate before calling, save each result immediately.
--check-only needs no API key and never calls a model.
--recover reads a saved checkpoint and exports CSV without model calls.
"""
import argparse
import csv
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
from datetime import datetime
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import uuid
import tempfile
import fcntl

WAIT_STATUS_SECONDS = 10
import time
import shutil
import threading

ROOT = Path(__file__).resolve().parent
DEFAULT_RESULT_DIR = Path.home()/'Desktop'/'诊前checklist'
RUNNER_VERSION = '2026-11-24-savefix-4'
FIELDS = ['批次ID','内容ID','判断','问题类型','问题定位','query','reasoning','response','status']

class CompactProgress:
    """One updating line on a terminal; sparse milestones in redirected logs."""
    def __init__(self,total):
        self.total=total;self.done=0;self.success=0;self.active=0;self.pending=total
        self.started=time.monotonic();self.stream=sys.stdout
        self.tty=bool(getattr(self.stream,'isatty',lambda:False)())
        self.lock=threading.RLock();self.last_bucket=-1;self.closed=False

    @staticmethod
    def clock(seconds):
        seconds=int(seconds);return f'{seconds//60:02d}:{seconds%60:02d}'

    def line(self,waiting=False):
        elapsed=time.monotonic()-self.started
        eta=self.clock(elapsed*(self.total-self.done)/self.done) if self.done else '?'
        rate=f'{elapsed/self.done:.2f}s/条' if self.done else '?s/条'
        pct=int(100*self.done/self.total) if self.total else 100
        columns=shutil.get_terminal_size((120,24)).columns
        width=max(6,min(20,columns-85));filled=int(width*pct/100)
        bar='█'*filled+'░'*(width-filled)
        text=f'处理进度: {pct:3d}%|{bar}| {self.done}/{self.total} [{self.clock(elapsed)}<{eta}, {rate}]'
        if columns>=100:text+=f' 成功 {self.success} · 异常 {self.done-self.success}'
        if waiting and self.active:text+=f' · 等待 {self.active}'
        return text

    def update(self,done,success,active,pending,waiting=False):
        with self.lock:
            self.done,self.success,self.active,self.pending=done,success,active,pending
            bucket=int(10*done/self.total) if self.total else 10
            if self.tty:
                self.stream.write('\r\x1b[2K'+self.line(waiting));self.stream.flush()
            elif bucket!=self.last_bucket:
                print(self.line(waiting),file=self.stream,flush=True)
            self.last_bucket=bucket

    def message(self,text):
        with self.lock:
            if self.tty:self.stream.write('\r\x1b[2K')
            print(text,file=self.stream,flush=True)
            if self.tty and not self.closed:
                self.stream.write(self.line());self.stream.flush()

    def close(self):
        with self.lock:
            self.closed=True
            if self.tty:self.stream.write('\n');self.stream.flush()

ACTIVE_PROGRESS=None

def status_message(text):
    if ACTIVE_PROGRESS is not None:ACTIVE_PROGRESS.message(text)
    else:print(text,flush=True)

def safe_error(message, secret):
    text = str(message)
    if secret:
        text = text.replace(secret, "[REDACTED]")
    return re.sub(r"sk-[A-Za-z0-9_-]+", "[REDACTED]", text)[:3000]

def call_api(query, args):
    headers = {
        "Authorization": f"Bearer {args.sk}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "model": args.model,
        "messages": [{"role": "user", "content": query}],
        "temperature": args.temp,
        "max_tokens": args.max_tokens,
        "stream": False
    }
    
    if args.think_budget is not None:
        payload["thinking"] = {
            "type": "enabled",
            "budget_tokens": args.think_budget
        }

    last_error = "No request attempted"
    for attempt in range(args.retry):
        try:
            response = requests.post(args.url, headers=headers, json=payload, timeout=180)
            if response.status_code == 200:
                data = response.json()
                choice = data['choices'][0]['message']
                
                content = choice.get('content', '')
                reasoning = ""
                if args.think:
                    reasoning = choice.get('reasoning_content') or choice.get('reasoning') or ""
                
                return {"query": query, "reasoning": reasoning, "response": content, "status": "success"}
            else:
                last_error = safe_error(
                    f"HTTP {response.status_code}: {response.text}", args.sk
                )
                status_message(f"[请求失败] {last_error}")
                if 400 <= response.status_code < 500 and response.status_code not in (408, 429):
                    break
        except Exception as exc:
            last_error = safe_error(f"{type(exc).__name__}: {exc}", args.sk)
            status_message(f"[请求异常] {last_error}")
        if attempt + 1 < args.retry:
            time.sleep(min(attempt + 1, 30))
            
    return {"query": query, "reasoning": "", "response": f"ERROR: {last_error}", "status": "failed"}

def validate_file(path):
    text=Path(path).read_text(encoding='utf-8-sig')
    queries=[];seen=set();prompts=set()
    for no,line in enumerate(text.splitlines(),1):
        if not line.strip():continue
        try:o=json.loads(line)
        except ValueError:raise ValueError(f'第 {no} 行不是有效 JSON') from None
        if not isinstance(o,dict) or not isinstance(o.get('checklist'),str) or not o['checklist'].strip():raise ValueError(f'第 {no} 行 checklist 为空或缺失')
        d=o.get('input_data')
        if not isinstance(d,dict):raise ValueError(f'第 {no} 行 input_data 缺失')
        for k in ['批次id','内容id','标注case']:
            if not isinstance(d.get(k),str) or not d[k].strip():raise ValueError(f'第 {no} 行 {k} 不是非空字符串')
        pair=(d['批次id'],d['内容id'])
        if pair in seen:raise ValueError(f'第 {no} 行批次与内容 ID 重复')
        seen.add(pair);prompts.add(o['checklist']);queries.append(line)
    if not queries:raise ValueError('输入文件没有记录')
    if len(prompts)!=1:raise ValueError('TXT 混入多个 checklist 版本')
    return queries

def output_path(path, input_file=None):
    if path:return Path(path).expanduser().resolve()
    source=Path(input_file).expanduser().resolve() if input_file else None
    directory=source.parent if source else DEFAULT_RESULT_DIR
    if not directory.is_dir():raise ValueError('输出目录不存在：'+str(directory))
    stem=source.stem if source else '恢复结果'
    target=directory/(stem+'_result.csv')
    return target


def preflight(path):
    """Check write access without truncating existing CSV/checkpoint files."""
    checkpoint=path.with_suffix(path.suffix+'.checkpoint.jsonl')
    for target in (path,checkpoint):
        if target.is_symlink():raise ValueError('结果路径不能是符号链接：'+str(target))
        if target.exists():
            fd=os.open(target,os.O_WRONLY)
            os.close(fd)
    with tempfile.NamedTemporaryFile(prefix='.writecheck-',dir=path.parent,mode='wb') as f:
        f.write(b'preflight');f.flush();os.fsync(f.fileno())


def reserve(path):
    # Overwrite is intentional for a real run. --check-only never calls reserve.
    preflight(path)
    checkpoint=path.with_suffix(path.suffix+'.checkpoint.jsonl')
    out=path.open('w',encoding='utf-8-sig',newline='')
    cp=None
    try:
        writer=csv.DictWriter(out,fieldnames=FIELDS,extrasaction='ignore');writer.writeheader()
        out.flush();os.fsync(out.fileno())
        cp=checkpoint.open('w',encoding='utf-8')
        cp.write(json.dumps({'kind':'checkpoint_header','schema':1,'output':str(path)})+'\n')
        cp.flush();os.fsync(cp.fileno())
        return out,cp,writer,checkpoint
    except BaseException:
        out.close()
        if cp:cp.close()
        raise


def result_fields(result,query):
    result={**result,'query':query}
    d=json.loads(query)['input_data']
    result.update({'批次ID':d['批次id'],'内容ID':d['内容id'],'判断':'','问题类型':'','问题定位':''})
    if result.get('status')=='success':
        text=result.get('response') or ''
        matches=list(re.finditer(r'^###\s*([^\n]+)\s*$',text,re.M))
        extracted={m.group(1).strip():text[m.end():matches[i+1].start() if i+1<len(matches) else len(text)].strip() for i,m in enumerate(matches)}
        result.update({k:extracted.get(k,'') for k in ['判断','问题类型','问题定位']})
        if result['判断'] not in ('合格','不合格') or not result['问题类型'] or not result['问题定位']:result['status']='parse_error'
    return result

def load_client():
    # Retain the original request payload, timeouts, model defaults and retry logic.
    # Import only when real requests will run; --check-only never needs a model client.
    global requests
    import requests
    return call_api


def run_queries(queries,args,call,out,cp,writer):
    global ACTIVE_PROGRESS
    progress=CompactProgress(len(queries));ACTIVE_PROGRESS=progress
    successes=0;completed=0;next_index=0;write_error=None
    started=time.monotonic()
    pool=ThreadPoolExecutor(max_workers=args.concurrency)
    futures={}
    try:
        def schedule():
            nonlocal next_index
            while write_error is None and len(futures)<args.concurrency and next_index<len(queries):
                i=next_index;next_index+=1
                futures[pool.submit(call,queries[i],args)]=i
        schedule()
        progress.update(0,0,len(futures),len(queries)-next_index,waiting=True)
        while futures:
            done,_=wait(futures,timeout=WAIT_STATUS_SECONDS,return_when=FIRST_COMPLETED)
            if not done:
                progress.update(completed,successes,len(futures),len(queries)-next_index,waiting=True)
            for future in done:
                index=futures.pop(future);q=queries[index]
                try:r=future.result()
                except Exception as exc:r={'status':'failed','response':'请求异常：'+type(exc).__name__,'reasoning':''}
                r=result_fields(r,q)
                # Save checkpoint BEFORE touching CSV; stop scheduling new requests
                # on CSV failure while retaining results of already in-flight calls.
                cp.write(json.dumps({'kind':'result','index':index,'result':r},ensure_ascii=False)+'\n')
                cp.flush();os.fsync(cp.fileno())
                if write_error is None:
                    try:
                        writer.writerow(r);out.flush();os.fsync(out.fileno())
                    except OSError as exc:
                        write_error=exc
                        progress.message('CSV 写入失败：已停止新增请求，正在保存已发出请求的检查点。')
                completed+=1;successes+=r['status']=='success'
                progress.update(completed,successes,len(futures),len(queries)-next_index)
            schedule()
        if write_error is not None:
            raise OSError('CSV 写入失败，但已完成请求保留在检查点；请使用 --recover 恢复。') from write_error
    finally:
        for future in futures:future.cancel()
        pool.shutdown(wait=True,cancel_futures=True)
        progress.close();ACTIVE_PROGRESS=None
    return successes


def recover(src,path):
    rows={}
    with Path(src).open(encoding='utf-8') as f:
        for i,line in enumerate(f,1):
            if not line.strip():continue
            try:r=json.loads(line)
            except ValueError:print(f'跳过损坏的检查点行 {i}',flush=True);continue
            if r.get('kind')=='result':rows[r['index']]=r['result']
    if not rows:raise ValueError('检查点没有可恢复的结果')
    preflight(path)
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=FIELDS,extrasaction='ignore');w.writeheader();w.writerows(rows[k] for k in sorted(rows))
    print(f'已恢复 {len(rows)} 条到 {path}；未调用模型')

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('-i','--input');p.add_argument('-o','--output');p.add_argument('-sk','--sk',default='')
    p.add_argument('-m','--model',default='doubao-seed-2-0-pro-260215')
    p.add_argument('-u','--url',default='http://10.104.29.36:8080/v1/chat/completions')
    p.add_argument('-c','--concurrency',type=int,default=10);p.add_argument('-r','--retry',type=int,default=10)
    p.add_argument('-t','--temp',type=float,default=1.0);p.add_argument('-mt','--max_tokens',type=int,default=40960)
    p.add_argument('--think',action='store_true');p.add_argument('--think_budget',type=int);p.add_argument('--limit',type=int)
    p.add_argument('--version',action='version',version=RUNNER_VERSION)
    p.add_argument('--check-only',action='store_true');p.add_argument('--recover',metavar='CHECKPOINT_JSONL')
    a=p.parse_args(argv)
    lock=None
    print('安全保存版 '+RUNNER_VERSION,flush=True)
    try:
        if a.recover:recover(a.recover,output_path(a.output,a.recover));return 0
        if not a.input:raise ValueError('请用 -i 指定输入 TXT')
        if a.concurrency<1 or a.retry<1 or (a.limit is not None and a.limit<1):raise ValueError('并发、重试和 limit 必须至少为 1')
        qs=validate_file(a.input)
        print(f'TXT 结构检查通过：{len(qs)} 条，ID 无重复，1 个 checklist 版本；尚未与 Excel 对比。',flush=True)
        if a.limit:qs=qs[:a.limit]
        if not a.check_only and not a.sk:raise ValueError('实际运行需要 -sk；只做检查请加 --check-only')
        call=None if a.check_only else load_client()
        path=output_path(a.output,a.input)
        if path==Path(a.input).expanduser().resolve():raise ValueError('输出 CSV 不能覆盖输入 TXT')
        # Prevent two new-version runs from truncating the same result concurrently.
        lock=path.with_suffix(path.suffix+'.lock').open('a')
        try:fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise ValueError('相同结果文件正在被另一个任务使用，请等待该任务结束') from None
        preflight(path)
        print('输出路径已通过实际写入检查：'+str(path),flush=True)
        if a.check_only:
            print('预检完成，未调用模型，未覆盖已有结果。');return 0
        print('同名覆盖模式：本次结果将替换同名 CSV 和检查点，不添加时间戳。',flush=True)
        out,cp,writer,checkpoint=reserve(path)
        print('检查点路径：'+str(checkpoint),flush=True)
        print('\n'+'='*64)
        print('AI 批量请求工具 · 逐条安全保存')
        print('输入文件：'+str(a.input))
        print('输出文件：'+str(path))
        print('模型：'+a.model)
        print(f'问题数量：{len(qs)} 条\n并发数：{a.concurrency}\n提取思考：'+('是' if a.think else '否'))
        print('='*64+'\n',flush=True)
        try:
            success_count=run_queries(qs,a,call,out,cp,writer)
        finally:out.close();cp.close()
        print(f'完成：已保存 {len(qs)} 条，成功解析 {success_count} 条，异常 {len(qs)-success_count} 条。\nCSV：{path}\n逐条检查点：{checkpoint}')
        return 0
    except Exception as e:
        message=str(e)
        if a.sk:message=message.replace(a.sk,'[REDACTED]')
        print('停止：'+message,file=sys.stderr)
        print('若已创建检查点，请保留 *.checkpoint.jsonl；可用 --recover 恢复已落盘结果，不必重复调用。',file=sys.stderr)
        return 1
    finally:
        if lock is not None:lock.close()

if __name__=='__main__':sys.exit(main())
