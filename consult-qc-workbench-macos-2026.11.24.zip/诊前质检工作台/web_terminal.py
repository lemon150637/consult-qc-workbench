"""Local-only PTY sessions. Transport is authenticated, ordered HTTP polling."""
import atexit
import base64
import fcntl
import os
from pathlib import Path
import secrets
import signal
import struct
import subprocess
import sys
import termios
import threading
import time

ROOT = Path(__file__).resolve().parent
AUTH = secrets.token_urlsafe(32)
LIMIT = 1024 * 1024
SESSIONS = {}
GUARD = threading.RLock()

class Session:
    def __init__(self, cols=100, rows=24):
        self.id = secrets.token_urlsafe(24)
        folder = Path.home() / 'Desktop' / '诊前checklist'
        self.cwd = str(folder if folder.is_dir() else ROOT)
        self.cv = threading.Condition(threading.RLock())
        self.input_lock = threading.Lock()
        self.buffer = bytearray()
        self.base = 0
        self.ended = False
        self.closed = False
        self.created = time.time()
        self.master, slave = os.openpty()
        self.resize(cols, rows)
        env = os.environ.copy()
        env.update(TERM='xterm-256color', COLORTERM='truecolor', LANG='en_US.UTF-8',
                   LC_CTYPE='UTF-8', HISTFILE='/dev/null', HISTSIZE='0', SAVEHIST='0',
                   PROMPT='%~ % ', PS1='%~ % ' if Path('/bin/zsh').exists() else '\\w $ ', PYTHONUNBUFFERED='1')
        # Keep user-installed Python and CLI programs discoverable without shell rc.
        paths = [str(ROOT/'.venv/bin'),str(Path.home()/'.local/bin'), '/opt/homebrew/bin', '/usr/local/bin',
                 str(Path(sys.executable).parent), env.get('PATH', '/usr/bin:/bin')]
        env['PATH'] = ':'.join(paths)
        try:
            self.process = subprocess.Popen([sys.executable, str(ROOT/'terminal_child.py'), str(slave)],
                                            cwd=self.cwd, env=env, pass_fds=(slave,), close_fds=True)
        except Exception:
            os.close(self.master)
            raise
        finally:
            os.close(slave)
        threading.Thread(target=self._read, daemon=True).start()

    def resize(self, cols, rows):
        if type(cols) is not int or type(rows) is not int or not 20 <= cols <= 400 or not 5 <= rows <= 200:
            raise ValueError('终端尺寸无效')
        with self.cv:
            if self.closed:
                raise ValueError('终端已关闭')
            fcntl.ioctl(self.master, termios.TIOCSWINSZ, struct.pack('HHHH', rows, cols, 0, 0))

    def _read(self):
        try:
            while True:
                data = os.read(self.master, 16384)
                if not data:
                    break
                with self.cv:
                    self.buffer.extend(data)
                    if len(self.buffer) > LIMIT:
                        n = len(self.buffer) - LIMIT
                        del self.buffer[:n]
                        self.base += n
                    self.cv.notify_all()
        except OSError:
            pass
        finally:
            self.process.wait()
            with self.cv:
                self.ended = True
                self.cv.notify_all()

    def read(self, cursor):
        if type(cursor) is not int or cursor < 0:
            raise ValueError('终端读取位置无效')
        with self.cv:
            if cursor > self.base + len(self.buffer):
                raise ValueError('终端读取位置超出范围')
            if cursor == self.base + len(self.buffer) and not self.ended:
                self.cv.wait(1)
            gap = cursor < self.base
            cursor = max(cursor, self.base)
            chunk = bytes(self.buffer[cursor-self.base:cursor-self.base+65536])
            return {'data':base64.b64encode(chunk).decode(), 'cursor':cursor+len(chunk),
                    'gap':gap, 'exited':self.ended, 'exit_code':self.process.poll()}

    def write(self, text):
        if not isinstance(text, str) or len(text.encode()) > 65536:
            raise ValueError('单次终端输入超过 64 KB')
        with self.input_lock:
            if self.closed or self.ended:
                raise ValueError('终端已退出，请重新连接')
            raw = text.encode('utf-8')
            while raw:
                count = os.write(self.master, raw)
                raw = raw[count:]

    def close(self):
        if self.closed:
            return
        self.closed = True
        if self.process.poll() is None:
            # Signal foreground jobs (which may have their own process group), then shell.
            try:
                foreground = os.tcgetpgrp(self.master)
                if foreground > 0 and foreground != os.getpgrp():
                    os.killpg(foreground, signal.SIGHUP)
            except (ProcessLookupError, OSError):
                pass
            try:
                os.kill(self.process.pid, signal.SIGHUP)
            except ProcessLookupError:
                pass
        try:
            os.close(self.master)
        except OSError:
            pass


def create(cols=100, rows=24):
    with GUARD:
        if sum(not s.ended and not s.closed for s in SESSIONS.values()) >= 4:
            raise ValueError('最多同时打开 4 个终端，请先关闭不用的终端')
        for sid in list(SESSIONS):
            if SESSIONS[sid].ended or SESSIONS[sid].closed:
                SESSIONS.pop(sid).close()
        s = Session(cols, rows)
        SESSIONS[s.id] = s
        return {'id':s.id, 'cwd':s.cwd, 'state':'connected'}


def dispatch(action, data):
    if action == 'create':
        return create(data.get('cols',100),data.get('rows',24))
    with GUARD:
        s = SESSIONS.get(data.get('id',''))
    if s is None:
        raise ValueError('终端会话不存在，服务可能已重启，请重新连接')
    if action == 'read':
        return s.read(data.get('cursor',0))
    if action == 'input':
        s.write(data.get('text',''))
    elif action == 'resize':
        s.resize(data.get('cols',100),data.get('rows',24))
    elif action == 'close':
        s.close()
    else:
        raise ValueError('未知终端操作')
    return {'ok':True}


@atexit.register
def cleanup():
    for session in list(SESSIONS.values()):
        session.close()
